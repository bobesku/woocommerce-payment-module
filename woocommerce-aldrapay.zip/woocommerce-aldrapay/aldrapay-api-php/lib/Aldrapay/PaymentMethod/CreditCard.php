<?php
namespace Aldrapay\PaymentMethod;

class CreditCard extends Base {
}
?>
