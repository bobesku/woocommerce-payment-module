<?php
namespace Aldrapay;

class PaymentHostedPageOperation extends AuthorizationHostedPageOperation {
}
?>
