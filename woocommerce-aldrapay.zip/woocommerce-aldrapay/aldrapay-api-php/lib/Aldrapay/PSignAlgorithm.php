<?php
namespace Aldrapay;

class PSignAlgorithm {
	
  public static $ALGO_SHA1  = 'sha1';
  public static $ALGO_SHA224  = 'sha224';
  public static $ALGO_SHA256  = 'sha256';
  public static $ALGO_SHA384  = 'sha384';
  public static $ALGO_SHA512  = 'sha512';
}